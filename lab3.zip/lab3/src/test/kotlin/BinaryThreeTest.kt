import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class BinaryThreeTest {

    var three = BinaryThree()

    @Test
    fun check() {
        three.add(10)
        assertTrue(three.check(10))
    }

    @Test
    fun add() {
        three.add(10)
        assertTrue(three.check(10))
    }

    @Test
    fun delete() {
        three.add(10)
        three.add(5)
        three.delete(5)
        assertTrue(three.check(5) == false)
    }
}